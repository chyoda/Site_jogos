<?php
//chamando a conexão
$servername = "localhost";
$database = "projeto_SA";
$username = "root";
$password = "02083003";

// Criando conexão
$conn = mysqli_connect($servername, $username, $password, $database);
// Checando conexão 
if (!$conn) {
    die("Conexão falhou: " . mysqli_connect_error());
}

if(isset($_POST['email']) && !empty($_POST['senha']))
{

    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM login WHERE email = '$email' AND senha = '$senha'";

    $result = $conn->query($sql);

    if(mysqli_num_rows($result) < 1){
        echo"<script language='javascript' type='text/javascript'>
        alert('Login e/ou senha incorretos');window.location
        .href='login.php';</script>";
        unset($_SESSION['user']);
        unset($_SESSION['senha']);
    
    }else{
        $_SESSION['email'] = $email;
        $_SESSION['senha'] = $senha; 
        echo"<script language='javascript' type='text/javascript'>
        alert('Entrou com Login');window.location
        .href='/codigos_html-main - Copia/TCC/Adm/adm.php';</script>";
        //header("Location:p-adm.php");
    }

    if (isset($entrar)) {
        $verifica = mysqli_query($conn,$sql) or die("erro ao selecionar");
    }
                                                                                                                                          
}
$conn->close();

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de cadastro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
        <nav class="nav-bar">
            <div class="aba">
                <a href="../Inicio/inicio.php">Início</a>
            </div>
            <div class="aba">
                <a href="../Historia/hist.html">História</a>
            </div>
            <div class="aba">
                <a href="../Ações/acoes.html">Ações</a>
            </div>
            <div class="aba">
                <a href="../Parcerias/parce.html">Parcerias</a>
            </div>
            <div  class="aba">
                <a href="../Login/login.php">Login</a>
            </div>
        </nav>
    </header>
    <main>
        <nav id="section">
            <img class="logo" src="../logo.png">
            <div id="cad">
                <h1>Entrar</h1>
                <form action="login.php" method="post">
                    <div id="form">
                        <div id="area-cad">
                            <label for="">Email:</label><br>
                            <input type="text" name="email" placeholder="Digite seu email"><br><br> 
                            <label for="">Senha:</label><br>
                            <input type="password" name="senha" placeholder="Digite sua senha"><br>
                            <h3 id="h3">Essa página é destinada apenas para organizadores do Projeto    </h3>
                        </div>
                    </div><br>
                    <div id="termos">
                        <input type="submit" name="entrar" value="Entrar" class="button">
                    </div>
                </form>
            </div>
        </nav>
    </main>
    <br><br><br><br>
    <footer> 
        <div class="container"> 
            <div class="logo1"> 
                <img src="../logo.png" alt=""> 
            </div> 
            <div class="info"> 
                <p>Projeto Social Servir & Amar © 2023. Todos os direitos reservados.</p> 
                <p>Email: 
                    <a href="mailto:projetosocialservireamar@gmail.com?subject=&body=" style="text-decoration: none; color: white">projetosocialservireamar@gmail.com
                </a></p> 
            </div> 
            <div class="social"> 
                <a href="https://www.instagram.com/projetosocialservireamar">
                    <img src="../logo-insta.jpg" alt="Instagram">
                </a> 
                <a href="https://www.youtube.com/channel/UC9w8w8w8w8w8w8w8w8w8w8w">
                    <img src="../whats.png" alt="Youtube">
                </a> 
            </div> 
        </div> 
    </footer>
</body>
</html>
