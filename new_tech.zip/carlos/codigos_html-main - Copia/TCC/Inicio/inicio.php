
<!DOCTYPE html>
<html lang="en" style="margin: 0; padding: 0; width: 100%;">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital@1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="inicio.css">
</head>
<body id="corpo">
    <header>
        <nav class="nav-bar">
            <div class="aba">
                <a href="../Inicio/inicio.php">Início</a>
            </div>
            <div class="aba">
                <a href="../Historia/hist.html">História</a>
            </div>
            <div class="aba">
                <a href="../Ações/acoes.html">Ações</a>
            </div>
            <div class="aba">
                <a href="../Parcerias/parce.html">Parcerias</a>
            </div>
            <div  class="aba">
                <a href="../Login/login.php">Login</a>
            </div>
        </nav>
    </header>
    <section>
        <div class="container">
            <div class="left">
                <img class="logo" src="../logo.png">
                <h1 style="width: 25vw;">Sobre Nós</h1>
                <p>
                    Olá, seja bem vindo ao site do Projeto Social<br>
                    Servir & Amar! Somos um grupo de pessoas,<br>
                    guiados por Deus para realizar a missão de levar<br> 
                    a palavra de Deus e ajudar o próximo, através de movimentos<br>
                    sociais, como por exemplo, entregas de cestas<br>
                    básicas, marmitas, ou até mesmo<br>
                    roupas, como também realizamos ações em<br>
                    algumas datas especiais, como por exemplo, o dia das crianças,<br>
                    entre outras.  
                </p>
            </div>
            <div class="right">
                <nav>
                    <div>
                        <img src="./imagem1.jpg" alt="Imagem 1"  class="I1" style="margin-right: 2vw; margin-top: 0;"> 
                    </div>
                    <div>
                        <img src="./imagem2.png" alt="Imagem 2" class="I2" style="margin-right: 2vw; margin-top: 0px;">
                    </div>
                </nav>
                <div>
                    <img src="./imagem3.jpg" alt="Imagem 3"  class="I3" style=" margin-top: 2vh;">

                </div>
            </div>
        </div>
    </section><br><br><br>
    <footer> 
        <div class="container"> 
            <div class="logo1"> 
                <img src="../logo.png" alt=""> 
            </div> 
            <div class="info"> 
                <p>Projeto Social Servir & Amar © 2023. Todos os direitos reservados.</p> 
                <p>Email: 
                    <a href="mailto:projetosocialservireamar@gmail.com?subject=&body=" style="text-decoration: none; color: white">projetosocialservireamar@gmail.com
                </a></p> 
            </div> 
            <div class="social"> 
                <a href="https://www.instagram.com/projetosocialservireamar">
                    <img src="../logo-insta.jpg" alt="Instagram">
                </a> 
                <a href="https://www.youtube.com/channel/UC9w8w8w8w8w8w8w8w8w8w8w">
                    <img src="../whats.png" alt="Youtube">
                </a> 
            </div> 
        </div> 
    </footer>

    
</body>
</html>