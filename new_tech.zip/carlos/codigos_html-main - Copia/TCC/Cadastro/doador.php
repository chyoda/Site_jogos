<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    //Chama a conexão
    $servername = "localhost";
    $database = "projeto_SA";
    $username = "root";
    $password = "02083003";
    
    // Criando conexão
    $conn = mysqli_connect($servername, $username, $password, $database);
    // Checando conexão 
    if (!$conn) {
        die("Conexão falhou: " . mysqli_connect_error());
    }
    
    // Pega os valores do formulário
    $nome = $_POST['nome'];
    $telefone = $_POST['tel'];
    $estado = $_POST['estado'];
    $cidade = $_POST['city'];
    $endereco = $_POST['end'];
    $email = $_POST['email'];
    $doacao = $_POST['tp_doacao'];

    $entrar = $_POST['entrar'];


    // Insere os dados no banco de dados
    $sql = "INSERT INTO test_doacoes (nome, telefone, email, endereço, estado, cidade, tp_conta, tp_doacao) 
    VALUES ('$nome', '$telefone', '$email' , '$endereco', '$estado', '$cidade', 'Doador', '$doacao')";

    if ($conn->query($sql) === TRUE) {  
    echo "Dados cadastrado com sucesso!";
    } else {
    echo "Erro ao cadastrar dados, por favor tente novamente. " . mysqli_error($conn);
    }

    if (isset($entrar)) {
        echo"<script language='javascript' type='text/javascript'>
        alert('Você precisa entrar em contato com um dos organizadores do projeto');window.location
        .href='../Contato/cont_doador.html';</script>";
    } 
    $conn->close();

    }

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de Doação</title>
    <link rel="stylesheet" href="doador.css">
</head>
<body>
    <header>
        <nav class="nav-bar">
            <div class="aba">
                <a href="../Inicio/inicio.php">Início</a>
            </div>
            <div class="aba">
                <a href="../Historia/hist.html">História</a>
            </div>
            <div class="aba">
                <a href="../Ações/acoes.html">Ações</a>
            </div>
            <div class="aba">
                <a href="../Parcerias/parce.html">Parcerias</a>
            </div>
            <div  class="aba">
                <a href="../Login/login.php">Login</a>
            </div>
        </nav>
    </header>
    <main>
        <nav id="section">
            <div id="logo">
                <img src="../logo.png" alt="">
            </div>
            <nav id="cad">
                <h1>Realize sua Doação</h1>
                <form action="doador.php" method="post">
                    <div id="form">
                        <div id="area-cad">
                            <div id="direita">
                                <input type="text" name="nome" title="Digite seu nome completo." placeholder="Nome *" required><br><br>
                                <input type="text" name="tel" title="Ex: (DDD) 99876-5432" placeholder="Telefone *" required><br><br>
                                <div id="area-dupla">
                                    <select name="estado" id="estado" required> <option value=“”>Selecione</option> 
                                        <option value="AC">Acre</option> <option value="AL">Alagoas</option> 
                                        <option value="AP">Amapá</option> <option value="AM">Amazonas</option> 
                                        <option value="BA">Bahia</option> <option value="CE">Ceará</option> 
                                        <option value="DF">Distrito Federal</option> <option value="ES">Espírito Santo</option> 
                                        <option value="GO">Goiás</option> <option value="MA">Maranhão</option> 
                                        <option value="MT">Mato Grosso</option> <option value="MS">Mato Grosso do Sul</option> 
                                        <option value="MG">Minas Gerais</option> <option value="PA">Pará</option> 
                                        <option value="PB">Paraíba</option> <option value="PR">Paraná</option> 
                                        <option value="PE" selected>PE</option> <option value="PI">Piauí</option> 
                                        <option value="RJ">Rio de Janeiro</option> <option value="RN">Rio Grande do Norte</option> 
                                        <option value="RS">Rio Grande do Sul</option> <option value="RO">Rondônia</option> 
                                        <option value="RR">Roraima</option> <option value="SC">Santa Catarina</option> 
                                        <option value="SP">São Paulo</option> <option value="SE">Sergipe</option> 
                                        <option value="TO">Tocantins</option> 
                                    </select>
                                    <div id="espaço"></div>
                                    <input type="text" name="city" id="city" placeholder="Cidade *" required> <br><br>

                                </div>
                            </div><br>
                            <div id="_"></div>
                            <div id="esquerda">
                                <input type="text" name="email" placeholder="Email *" required><br><br>
                                <input type="tex" name="end" title="Ex: Nome da rua, nº da casa" placeholder="Endereço *" required><br><br>
                                <select name="tp_doacao" id="doacao">
                                    <option value=" ">Forma de doação *</option>
                                    <option value="Alimento">Alimento</option>
                                    <option value="Dinheiro">Dinheiro</option>  
                                    <option value="Roupas">Roupa</option>  
                                </select>

                            </div><br>
                        </div>
                    </div>
                    <a href="" style="text-decoration: none;">
                        <input type="submit" name="entrar" value="Enviar" id="button">
                    </a><br><br>     
                    <div id="termos">
                        <input type="checkbox" name="" class="checkbox" required>
                        <label for="">Aceito os termos e condições</label><br><br>
                    </div>
                </form>
            </nav>
        </nav>
    </main><br><br><br>
    <footer> 
        <div class="container"> 
            <div class="logo1"> 
                <img src="../logo.png" alt=""> 
            </div> 
            <div class="info"> 
                <a href="/codigos_html-main - Copia\TCC\Termos\index.html">Termos de uso</a>
                <p>Projeto Social Servir & Amar © 2023. Todos os direitos reservados.</p> 
                <p>Email: projetosocialservireamar@gmail.com</p> 
            </div> 
            <div class="social"> 
                <a href="https://www.instagram.com/projetoservireamar.oficial/">
                    <img src="../instagram-icon.png" alt="Instagram"><br>
                    <h4>Instagram</h4>
                </a> 
                <a href="#">
                    <img src="../whats.png" alt="WhatsApp"><br>
                    <h4>WhatsApp</h4>
                </a> 
            </div> 
        </div> 
    </footer>
</body>
</html>