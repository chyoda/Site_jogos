<?php


if ($_SERVER["REQUEST_METHOD"] == "POST") {

    //Chama a conexão
    $servername = "localhost";
    $database = "projeto_SA";
    $username = "root";
    $password = "02083003";
    
    // Criando conexão
    $conn = mysqli_connect($servername, $username, $password, $database);
    // Checando conexão 
    if (!$conn) {
        die("Conexão falhou: " . mysqli_connect_error());
    }
    
    // Pega os valores do formulário
    $nome = $_POST['nome'];
    $telefone = $_POST['tel'];
    $estado = $_POST['estado'];
    $cidade = $_POST['city'];
    $endereco = $_POST['end'];
    $bairro = $_POST['bairro'];
    $zona = $_POST['zona'];
    $empregados = $_POST['trabalho'];
    $moradores = $_POST['moradia'];
    $descricao = $_POST['necessidade'];
    $data = $_POST['data'];
    $renda = $_POST['renda'];

    $entrar = $_POST['entrar'];


    // Insere os dados no banco de dados
    $sql = "INSERT INTO test_solicitacoes(nome, telefone, endereço, estado, cidade, bairro, zona, empregados, moradores, tp_conta, `data`, renda, necessidade) 
    VALUES ('$nome', '$telefone', '$endereco', '$estado', '$cidade', '$bairro', '$zona', '$empregados', '$moradores', 'receptor', '$data', '$renda', '$descricao')";

    if ($conn->query($sql) === TRUE) {  
    echo "Dados cadastrado com sucesso!";
    } else {
    echo "Erro ao cadastrar jogador: " . mysqli_error($conn);
    }

    if (isset($entrar)) {
        echo"<script language='javascript' type='text/javascript'>
        alert('Você precisa enviar um comprovante de renda para um dos organizadores do projeto');window.location
        .href='../Contato/cont_receptor.html';</script>";
    } 
    $conn->close();

    }


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página de cadastro</title>
    <link rel="stylesheet" href="receptor.css">
</head>
<body>
    <header>
        <nav class="nav-bar">
            <div class="aba">
                <a href="../Inicio/inicio.php">Início</a>
            </div>
            <div class="aba">
                <a href="../Historia/hist.html">História</a>
            </div>
            <div class="aba">
                <a href="../Ações/acoes.html">Ações</a>
            </div>
            <div class="aba">
                <a href="../Parcerias/parce.html">Parcerias</a>
            </div>
            <div  class="aba">
                <a href="../Login/login.php">Login</a>
            </div>
        </nav>
    </header>
    <main>
        <nav id="section">
            <div id="logo">
                <img src="\codigos_html-main - Copia\TCC\logo.png" alt="">
            </div>
            <div id="cad">
                <h1>Solicite sua Doação</h1>
                <form action="receptor.php" method="post">
                    <div id="form">
                        <div id="area-cad">
                            <div id="direita">
                                <input type="text" title="Digite seu nome completo" name="nome" placeholder="Nome *" required><br><br>
                                <input type="text" title="Ex: (DDD) 98765-4321" name="tel" placeholder="Telefone *" required><br><br>
                                <div id="area-dupla">
                                    <select name="estado" id="estado" required> <option value=“”>Selecione</option> 
                                        <option value="AC">Acre</option> <option value="AL">Alagoas</option> 
                                        <option value="AP">Amapá</option> <option value="AM">Amazonas</option> 
                                        <option value="BA">Bahia</option> <option value="CE">Ceará</option> 
                                        <option value="DF">Distrito Federal</option> <option value="ES">Espírito Santo</option> 
                                        <option value="GO">Goiás</option> <option value="MA">Maranhão</option> 
                                        <option value="MT">Mato Grosso</option> <option value="MS">Mato Grosso do Sul</option> 
                                        <option value="MG">Minas Gerais</option> <option value="PA">Pará</option> 
                                        <option value="PB">Paraíba</option> <option value="PR">Paraná</option> 
                                        <option value="PE" selected>PE</option> <option value="PI">Piauí</option> 
                                        <option value="RJ">Rio de Janeiro</option> <option value="RN">Rio Grande do Norte</option> 
                                        <option value="RS">Rio Grande do Sul</option> <option value="RO">Rondônia</option> 
                                        <option value="RR">Roraima</option> <option value="SC">Santa Catarina</option> 
                                        <option value="SP">São Paulo</option> <option value="SE">Sergipe</option> 
                                        <option value="TO">Tocantins</option> 
                                    </select>
                                    <div id="espaço"></div>
                                    <input type="text" name="city" id="city" placeholder="Cidade *"value="Agrestina" required> <br><br>
                                </div> <br>
                                <input type="tex" title="Ex: Santos Drummond, 123" name="end" placeholder="Endereço *" required><br><br>
                            </div><br>
                            <div id="_"></div>
                            
                            <div id="esquerda">
                                <input type="number" name="trabalho" placeholder="Quantas pessoas trabalham na sua casa? *" required><br><br>
                                <input type="number" name="moradia" placeholder="Quantas pessoas residem na sua casa? *" required><br><br>
                                <select name="renda" id="renda" required>
                                    <option value="#">Renda Familiar *</option>
                                    <option value="Menos de R$651,00">Menos de R$651,00</option>
                                    <option value="Meio salário mínimo (R$ 651,00)">Meio salário mínimo (R$ 651,00)</option>
                                    <option value="Entre R$651,00 e R$1. 320,00">Entre R$651,00 e R$1. 320,00</option>
                                    <option value="1 salário mínimo (R$1.320,00)">1 salário mínimo (R$1.320,00)</option>
                                    <option value="Mais de 1 salário mínimo">Mais de 1 salário mínimo</option>
                                </select><br><br>
                                
                                <input type="date" title="Selecione a data de hoje" name="data" id="data" placeholder="Data de hoje" required>
                                <br><br>
                                <input type="tex" name="bairro" placeholder="Bairro *" required><br><br>

                            </div><br>
                        </div>
                        <div style="margin-top: -8vh; margin-left: 5vw; color: #771413;">
                                <label for="zona">Zona:</label><br>
                                <div style="display: flex;">
                                    <input type="radio" name="zona" value="Urbana"><label for="urbana">Urbana</label>
                                    <input type="radio" name="zona" value="Rural"><label for="rural">Rural</label>
                                </div>
                            </div>
                    </div><br><br><br> 
                    <fieldset>
                        <legend>Necessidade Específica *</legend>
                        <textarea name="necessidade" id="" cols="30" rows="10" minlength=""></textarea>
                    </fieldset><br>
                    <input type="submit" name="entrar" value="Entrar" id="button"><br><br>
                    <div id="termos">
                        <input type="checkbox" name="" class="checkbox" required>
                        <label for="">Aceito os termos e condições</label><br><br>
                    </div>
                </form>
                
            </nav>
        </nav>
    </main>
    <footer> 
        <div class="container"> 
            <div class="logo1"> 
                <img src="../logo.png" alt=""> 
            </div> 
            <div class="info"> 
                <a href="/codigos_html-main - Copia\TCC\Termos\index.html">Termos de uso</a>
                <p>Projeto Social Servir & Amar © 2023. Todos os direitos reservados.</p> 
                <p>Email: projetosocialservireamar@gmail.com</p> 
            </div> 
            <div class="social"> 
                <a href="https://www.instagram.com/projetoservireamar.oficial/">
                    <img src="../instagram-icon.png" alt="Instagram"><br>
                    <h4>Instagram</h4>
                </a> 
                <a href="#">
                    <img src="../whats.png" alt="WhatsApp"><br>
                    <h4>WhatsApp</h4>
                </a> 
            </div> 
        </div> 
    </footer>
</body>
</html>