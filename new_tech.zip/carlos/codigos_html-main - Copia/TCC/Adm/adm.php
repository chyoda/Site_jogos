<!DOCTYPE html>
<html lang="en" style="margin: 0; padding: 0; width: 100%;">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital@1&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="adm.css">
</head>
<bod>
    <header>
        <nav class="nav-bar">
            <div class="aba">
                <a href="../Inicio/inicio.php">Início</a>
            </div>
            <div class="aba">
                <a href="../Historia/hist.html">História</a>
            </div>
            <div class="aba">
                <a href="../Ações/acoes.html">Ações</a>
            </div>
            <div class="aba">
                <a href="../Parcerias/parce.html">Parcerias</a>
            </div>
            <div  class="aba">
                <a href="../Login/login.php">Login</a>
            </div>
        </nav>
    </header>
    <div id="_"></div>
    <main>
        <div id="logo">
            <img src="/codigos_html-main - Copia\TCC\logo.png" alt="logo">
        </div>
        <nav>
            <div class="op">
                <button class="botoes" onclick="mostrar(areatable)">Solicitações</button>
            </div>
            <div class="op">
                <button class="botoes"  onclick="mostrar1(areatable1)">Doações</button>
            </div>

        </nav>
        <br>
        <div id="solicitacoes">

            <table class="tb tr" id="areatable">
       
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>Endereço</th>
                    <th>Estado</th>
                    <th>Cidade</th>
                    <th>Bairro</th>
                    <th>Zona</th>
                    <th>Renda</th>
                    <th>Data</th>
                    <th>Necessidade</th>
                </tr>
    
                <?php
    
                  //Chama a conexão
                  $servername = "localhost";
                  $database = "projeto_SA";
                  $username = "root";
                  $password = "02083003";
                  
                  // Criando conexão
                  $conn = mysqli_connect($servername, $username, $password, $database);
                  // Checando conexão 
                  if (!$conn) {
                      die("Conexão falhou: " . mysqli_connect_error());
                  }
    
                if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true)){
                    unset($_SESSION['email']);
                    unset($_SESSION['senha']);
                }
    
                    // Obtém os jogadores da turma selecionada
                    $sql = "SELECT cod, nome, telefone, endereço, estado, cidade, bairro, zona, tp_conta, renda, necessidade,  DATE_FORMAT (`data`,
                    '%d/%m/%Y') AS data_formatada FROM test_solicitacoes WHERE tp_conta = 'receptor'";

                    $result_nome = $conn->query($sql);
    
                    if ($result_nome->num_rows > 0) {
                        
                        while ($row = $result_nome->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["cod"] . "</td>";
                            echo "<td>" . $row["nome"] . "</td>";
                            echo "<td>" . $row["telefone"] . "</td>";
                            echo "<td>" . $row["endereço"] . "</td>";
                            echo "<td>" . $row["estado"] . "</td>";
                            echo "<td>" . $row["cidade"] . "</td>";
                            echo "<td>" . $row["bairro"] . "</td>";
                            echo "<td>" . $row["zona"] . "</td>";
                            echo "<td>" . $row["renda"] . "</td>";
                            echo "<td>" . $row["data_formatada"] . "</td>";
                            echo "<td>" . $row["necessidade"] . "</td> <br>";
                        }
                        echo "</tr>";
                    }else {
                        echo"<script language='javascript' type='text/javascript'>
                        alert('Nenhum dado cadastrado');</script>";
                    }
                       
                    $conn->close();

                ?>
            </table>
        </div>
        <div id="doacoes">

            <table class="tb tr" id="areatable1">
       
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>Telefone</th>
                    <th>Endereço</th>
                    <th>Estado</th>
                    <th>Cidade</th>
                    <th>Tipo de Doação</th>
                </tr>
    
                <?php
    
                  //Chama a conexão
                  $servername = "localhost";
                  $database = "projeto_SA";
                  $username = "root";
                  $password = "02083003";
                  
                  // Criando conexão
                  $conn = mysqli_connect($servername, $username, $password, $database);
                  // Checando conexão 
                  if (!$conn) {
                      die("Conexão falhou: " . mysqli_connect_error());
                  }
    
                if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true)){
                    unset($_SESSION['email']);
                    unset($_SESSION['senha']);
                }
    
                    // Obtém os jogadores da turma selecionada
                    $sql = "SELECT cod, nome, telefone, endereço, estado, cidade, tp_doacao
                    FROM test_doacoes WHERE tp_conta = 'doador'";
                    $result_nome = $conn->query($sql);
    
                    if ($result_nome->num_rows > 0) {
                        
                        while ($row = $result_nome->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["cod"] . "</td>";
                            echo "<td>" . $row["nome"] . "</td>";
                            echo "<td>" . $row["telefone"] . "</td>";
                            echo "<td>" . $row["endereço"] . "</td>";
                            echo "<td>" . $row["estado"] . "</td>";
                            echo "<td>" . $row["cidade"] . "</td>";
                            echo "<td>" . $row["tp_doacao"] . "</td> <br>";
                        }
                        echo "</tr>";
                    } else {
                        echo"<script language='javascript' type='text/javascript'>
                        alert('Nenhum dado cadastrado');</script>";
                    }
                    $conn->close();

                ?>
            </table>
        </div>
        <br><br><br><br><br>
        <br><br>
        <div id="height"></div>
    </main>
    <br><br><br><br><br><br><br>
    <footer> 
        <div class="container"> 
            <div class="logo1"> 
                <img src="../logo.png" alt=""> 
            </div> 
            <div class="info"> 
                <p>Projeto Social Servir & Amar © 2023. Todos os direitos reservados.</p> 
                <p>Email: projetosocialservireamar@gmail.com</p> 
            </div> 
            <div class="social"> 
                <a href="https://www.instagram.com/projetosocialservireamar">
                    <img src="../instagram-icon.png" alt="Instagram"><br>
                    <h4>Instagram</h4>
                </a> 
                <a href="https://www.youtube.com/channel/UC9w8w8w8w8w8w8w8w8w8w8w">
                    <img src="../whats.png" alt="WhatsApp"><br>
                    <h4>WhatsApp</h4>
                </a> 
            </div> 
        </div> 
    </footer>

</body>
<script>
    function mostrar(areatable) {
        var table = document.getElementById("areatable");
        if (table.style.display == "none") {
            table.style.display = "block";
        } else {
            table.style.display = "none";
        }
    }
    function mostrar1(areatable1) {
        var table = document.getElementById("areatable1");
        if (table.style.display == "none") {
            table.style.display = "block";
        } else {
            table.style.display = "none";
        }
    }
</script>
</html>